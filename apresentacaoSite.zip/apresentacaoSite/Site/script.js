   function exibirSelecionados() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
    let itensSelecionados = [];

    checkboxes.forEach(checkbox => {
        if (checkbox.checked) {
            itensSelecionados.push(checkbox.value);
        }
    });

    const resultadoDiv = document.getElementById('resultado');
    if (itensSelecionados.length > 0) {
        resultadoDiv.innerHTML = 'Itens Selecionados para pagamento: ' + itensSelecionados.join('; ');
    } else {
        resultadoDiv.innerHTML = 'Nenhum item no carrinho.';
    }
}


function pagamento() {
    var checkboxes = document.querySelectorAll('input[type="radio"]');
    let pagamento = [];

}

 /*  ************************************************************************************************* */



const resultadoDiv = document.getElementById('pagamento');
    if (pagamento.length > 0) {
        resultadoDiv.innerHTML = 'Forma de pagamento: ' + pagamento.join(', ');
    } else {
        resultadoDiv.innerHTML = 'Nenhuma Forma de pagamento selecionada.';
    }








    
 function calcularSoma(){

    let soma =0;

    if (document.getElementById('valor1').checked) {
    soma += parseInt(document.getElementById('valor1').value);
}
if (document.getElementById('valor2').checked) {
    soma += parseInt(document.getElementById('valor2').value);
}
    
if (document.getElementById('valor3').checked) {
    soma += parseInt(document.getElementById('valor3').value);
}    
    
if (document.getElementById('valor4').checked) {
    soma += parseInt(document.getElementById('valor4').value);
}    
    
if (document.getElementById('valor5').checked) {
    soma += parseInt(document.getElementById('valor5').value);
}

if (document.getElementById('valor6').checked) {
    soma += parseInt(document.getElementById('valor6').value);
}

if (document.getElementById('valor7').checked) {
    soma += parseInt(document.getElementById('valor7').value);
}

if (document.getElementById('valor8').checked) {
    soma += parseInt(document.getElementById('valor8').value);
}

if (document.getElementById('valor9').checked) {
    soma += parseInt(document.getElementById('valor9').value);
}

if (document.getElementById('valor10').checked) {
    soma += parseInt(document.getElementById('valor10').value);
}

document.getElementById('resultado').textContent='Valor a ser pago: R$'+soma.toLocaleString('pt-br');


}

  


